(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-01fdb9bd.js")
    );
  })().catch(console.error);

})();
