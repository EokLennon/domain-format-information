console.info("chrome-ext template-vanilla-ts background script");
